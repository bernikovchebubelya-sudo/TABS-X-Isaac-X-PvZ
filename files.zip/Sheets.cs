using System.Collections.Generic;
namespace LawnWobblers
{
    public class ZombieRow { public string id, pvzName, tabsProxy; public int hp, sunCost, unlockWave; public float speed; }
    public class IsaacUnitRow { public string id, isaacName, anm2, behavior, tabsProxy; public int sunCost; public bool isBoss; }
    public class ItemRow { public string id, isaacName, effect; public float value; }
    public class WaveRow { public int wave, sunIncome; public List<string> zombies; public bool isFinal; }
    public class ProxyRow { public string id, tabsUnit; }

    public class Sheets
    {
        public List<ZombieRow> zombies; public List<IsaacUnitRow> units; public List<ItemRow> items;
        public List<WaveRow> waves; public List<ProxyRow> proxies;
    }
}
