using System.Collections.Generic;
using System.Linq;
namespace LawnWobblers
{
    // Run before every build: lists unresolved references and unfilled cells.
    public static class Preflight
    {
        public static List<string> Run(Sheets s)
        {
            var errs = new List<string>();
            var proxies = new HashSet<string>(s.proxies.Select(p => p.id));
            foreach (var p in s.proxies)
                if (string.IsNullOrEmpty(p.tabsUnit) || p.tabsUnit.StartsWith("FILL_"))
                    errs.Add($"proxy '{p.id}': tabsUnit not filled");
            foreach (var z in s.zombies)
                if (!proxies.Contains(z.tabsProxy)) errs.Add($"zombie '{z.id}': unknown proxy '{z.tabsProxy}'");
            foreach (var u in s.units)
            {
                if (!proxies.Contains(u.tabsProxy)) errs.Add($"unit '{u.id}': unknown proxy '{u.tabsProxy}'");
                if (string.IsNullOrEmpty(u.anm2)) errs.Add($"unit '{u.id}': anm2 missing");
            }
            var zIds = new HashSet<string>(s.zombies.Select(z => z.id));
            foreach (var w in s.waves)
                foreach (var id in w.zombies)
                    if (!zIds.Contains(id)) errs.Add($"wave {w.wave}: unknown zombie '{id}'");
            return errs;
        }
    }
}
