namespace LawnWobblers
{
    // Everything game-specific lives behind this interface. NOT implemented yet:
    // needs inspection of the real TABS install (Unity) and Isaac files.
    public interface IGameAdapter
    {
        void SpawnEnemy(ZombieRow z, int lane);                 // spawn TABS proxy unit, apply PvZ stats/skin
        void SpawnPlayerIsaacUnit(IsaacUnitRow u, float x, float y); // load .anm2 + behavior from Isaac folder
        void ApplyItem(ItemRow item);                           // modify stats of all player units
        int  AliveEnemies();
        int  AlivePlayerUnits();
        void ShowMessage(string text);
    }
}
