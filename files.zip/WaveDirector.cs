using System;
using System.Collections.Generic;
using System.Linq;
namespace LawnWobblers
{
    // PvZ-style director: each wave has "sun" income; sun is spent on zombies
    // (cost from sheet) until it runs out. Player also spends sun on Isaac units.
    public class WaveDirector
    {
        readonly Sheets sheets; readonly IGameAdapter game; readonly Random rng;
        public int Wave { get; private set; }
        public int PlayerSun { get; private set; } = 12;   // starting budget
        public const int Lanes = 5;
        public List<string> PickedItems = new List<string>();

        public WaveDirector(Sheets s, IGameAdapter g, int seed = 0) { sheets = s; game = g; rng = new Random(seed); }

        public bool PickItem(string id)
        {
            if (PickedItems.Count >= 3) return false;          // 2-3 items at start
            var it = sheets.items.FirstOrDefault(i => i.id == id);
            if (it == null) return false;
            PickedItems.Add(id); game.ApplyItem(it); return true;
        }

        public bool BuyUnit(string id, float x, float y)
        {
            var u = sheets.units.FirstOrDefault(v => v.id == id);
            if (u == null || u.sunCost > PlayerSun) return false;
            PlayerSun -= u.sunCost; game.SpawnPlayerIsaacUnit(u, x, y); return true;
        }

        // Builds the spawn list for a wave without touching the game (testable).
        public List<ZombieRow> PlanWave(int wave)
        {
            var row = sheets.waves.First(w => w.wave == wave);
            var pool = sheets.zombies.Where(z => row.zombies.Contains(z.id) && z.unlockWave <= wave).ToList();
            var plan = new List<ZombieRow>(); int sun = row.sunIncome;
            while (true)
            {
                var affordable = pool.Where(z => z.sunCost <= sun).ToList();
                if (affordable.Count == 0) break;
                var pick = affordable[rng.Next(affordable.Count)];
                plan.Add(pick); sun -= pick.sunCost;
            }
            return plan;
        }

        public IEnumerable<ZombieRow> StartNextWave()
        {
            Wave++;
            var plan = PlanWave(Wave);
            game.ShowMessage(Wave == sheets.waves.Last().wave ? "Final wave!" : $"Wave {Wave}");
            foreach (var z in plan) game.SpawnEnemy(z, rng.Next(Lanes));
            return plan;
        }

        // Call each frame/tick. Returns "win", "lose" or null.
        public string Tick()
        {
            if (game.AlivePlayerUnits() == 0) return "lose";
            if (game.AliveEnemies() == 0)
            {
                if (Wave >= sheets.waves.Last().wave) return "win";
                PlayerSun += sheets.waves.First(w => w.wave == Wave + 1).sunIncome / 2; // sun between waves
                StartNextWave();
            }
            return null;
        }
    }
}
